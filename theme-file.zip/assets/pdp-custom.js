/* ---------- Color swatches ---------- */
const colorRow = document.getElementById('colorRow');
COLORS.forEach(c => {
  const el = document.createElement('div');
  el.className = 'color-sw' + (c.id === state.color ? ' active' : '') + (c.sold ? ' sold' : '');
  el.dataset.color = c.id;
  el.title = c.name + (c.sold ? ' (Sold out)' : '');
  el.innerHTML = `<div class="bg" style="background:${c.hex};"></div>`;
  colorRow.appendChild(el);
});
colorRow.addEventListener('click', e => {
  const sw = e.target.closest('.color-sw');
  if (!sw || sw.classList.contains('sold')) return;
  state.color = sw.dataset.color;
  colorRow.querySelectorAll('.color-sw').forEach(x => x.classList.toggle('active', x === sw));
  const meta = COLORS.find(c => c.id === state.color);
  document.getElementById('colorLab').textContent = meta.name;
  // Update gallery tones
  document.querySelectorAll('#thumbStrip .ph, #mainPh').forEach(p => p.dataset.tone = meta.tone);
  document.querySelector('#toast .ti .ph').dataset.tone = meta.tone;
  updateConfirm();
});

/* ---------- Sizes ---------- */
function renderSizes(rowEl, sizes, kind) {
  rowEl.innerHTML = '';
  sizes.forEach(s => {
    const wrap = document.createElement('div');
    wrap.className = 'size-wrap';
    const btn = document.createElement('button');
    btn.className = 'size' + (s.sold ? ' sold' : '') + (s.low ? ' low' : '') + (state[kind] === s.v ? ' active' : '');
    btn.dataset.v = s.v;
    btn.dataset.sold = s.sold ? '1' : '';
    let inner = `<span>${s.fast && !s.sold ? '<span class="fast">⚡</span>' : ''}${s.v}</span>`;
    if (s.low) inner += `<span class="sub">1 left</span>`;
    btn.innerHTML = inner;
    wrap.appendChild(btn);
    if (s.sold) {
      const alt = document.createElement('span');
      alt.className = 'alt';
      alt.textContent = 'View Similar';
      alt.dataset.size = s.v;
      alt.dataset.kind = kind;
      wrap.appendChild(alt);
    }
    rowEl.appendChild(wrap);
  });
}
renderSizes(document.getElementById('topRow'), TOP_SIZES, 'top');
renderSizes(document.getElementById('botRow'), BOT_SIZES, 'bot');

function bindSizes(rowEl, kind, labId) {
  rowEl.addEventListener('click', e => {
    const btn = e.target.closest('.size');
    const alt = e.target.closest('.alt');
    if (alt) { openSimilar(alt.dataset.size, alt.dataset.kind); return; }
    if (!btn || btn.dataset.sold === '1') return;
    state[kind] = btn.dataset.v;
    rowEl.querySelectorAll('.size').forEach(x => x.classList.toggle('active', x === btn));
    document.getElementById(labId).textContent = btn.dataset.v;
    updateConfirm();
  });
}
bindSizes(document.getElementById('topRow'), 'top', 'topLab');
bindSizes(document.getElementById('botRow'), 'bot', 'botLab');

/* ---------- Confirmation bar ---------- */
function updateConfirm() {
  const meta = COLORS.find(c => c.id === state.color);
  if (state.color && state.top && state.bot) {
    const txt = `${meta.name} · Top ${state.top} · Bottom ${state.bot} · Qty ${state.qty}`;
    document.getElementById('confirmText').textContent = txt;
    document.getElementById('confirm').classList.add('show');
    document.getElementById('toastVar').textContent = txt;
  }
}
updateConfirm();

/* ---------- Quantity ---------- */
const qVal = document.getElementById('qVal');
document.getElementById('qMinus').addEventListener('click', () => { if (state.qty > 1) { state.qty--; qVal.textContent = state.qty; updateConfirm(); } });
document.getElementById('qPlus').addEventListener('click', () => { if (state.qty < 9) { state.qty++; qVal.textContent = state.qty; updateConfirm(); } });

/* ---------- Wishlist toggle ---------- */
document.getElementById('wishlist').addEventListener('click', e => e.currentTarget.classList.toggle('active'));

/* ---------- Gallery thumbnails ---------- */
const mainPh = document.getElementById('mainPh');
document.getElementById('thumbStrip').addEventListener('click', e => {
  const t = e.target.closest('.thumb');
  if (!t) return;
  if (t.classList.contains('video')) { openLightbox(); return; }
  document.querySelectorAll('.thumb').forEach(x => x.classList.toggle('active', x === t));
  const labels = ['Front','Back','Embroidery detail','Flat lay','Model'];
  mainPh.textContent = `Dragonfly Coord Set · ${labels[t.dataset.i] || ''}`;
});

/* Double-tap zoom (mobile) */
const mainImg = document.getElementById('mainImg');
let lastTap = 0;
mainImg.addEventListener('click', e => {
  if (e.target.closest('.float-vid') || e.target.closest('.gal-pill') || e.target.closest('.gal-watch')) return;
  const now = Date.now();
  if (now - lastTap < 320) mainImg.classList.toggle('zoom');
  lastTap = now;
});

/* Float video */
document.getElementById('floatVid').addEventListener('click', e => {
  if (e.target.closest('.vid-close')) return;
  openLightbox();
});

/* ---------- Lightbox ---------- */
function openLightbox(){ document.getElementById('lightbox').classList.add('show'); }
function closeLightbox(){ document.getElementById('lightbox').classList.remove('show'); }

/* ---------- Accordions ---------- */
document.querySelectorAll('.acc').forEach(acc => {
  const head = acc.querySelector('.acc-head');
  const body = acc.querySelector('.acc-body');
  if (acc.classList.contains('open')) body.style.maxHeight = body.scrollHeight + 'px';
  head.addEventListener('click', () => {
    const isOpen = acc.classList.contains('open');
    document.querySelectorAll('.acc.open').forEach(o => {
      o.classList.remove('open');
      o.querySelector('.acc-body').style.maxHeight = '0px';
    });
    if (!isOpen) {
      acc.classList.add('open');
      body.style.maxHeight = body.scrollHeight + 'px';
    }
  });
});